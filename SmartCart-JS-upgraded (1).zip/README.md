# SmartCart-JS
Full-stack retail demo with Node.js backend and React frontend.

Run backend:
cd backend
npm install
npm start

Run frontend:
create a React app and replace src/App.js with frontend/src/App.js

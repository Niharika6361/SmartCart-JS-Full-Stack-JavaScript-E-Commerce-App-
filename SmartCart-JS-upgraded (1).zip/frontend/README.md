React frontend. Run with create-react-app or include in your React project.

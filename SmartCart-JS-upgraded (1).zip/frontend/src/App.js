import React, {useEffect, useState} from 'react';
import axios from 'axios';
export default function App(){
  const [products,setProducts]=useState([]);
  const [name,setName]=useState(''); const [price,setPrice]=useState('');
  useEffect(()=>{ axios.get('http://localhost:5001/api/products').then(r=>setProducts(r.data)).catch(()=>{}); },[]);
  const add = ()=>{ axios.post('http://localhost:5001/api/products',{name,price:parseFloat(price)}).then(()=>{ setName(''); setPrice(''); return axios.get('http://localhost:5001/api/products');}).then(r=>setProducts(r.data)); };
  return (<div style={{padding:20}}><h1>SmartCart-JS</h1><div><input placeholder='name' value={name} onChange={e=>setName(e.target.value)} /> <input placeholder='price' value={price} onChange={e=>setPrice(e.target.value)} /> <button onClick={add}>Add</button></div><ul>{products.map(p=><li key={p.id}>{p.name} - ₹{p.price}</li>)}</ul></div>);
}

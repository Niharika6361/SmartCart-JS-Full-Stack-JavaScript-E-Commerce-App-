const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const app = express();
app.use(cors());
app.use(bodyParser.json());

let products = [
  { id: 1, name: 'Apple', price: 10.5 },
  { id: 2, name: 'Banana', price: 5.0 }
];

app.get('/api/products', (req, res) => res.json(products));

app.post('/api/products', (req, res) => {
  const { name, price } = req.body;
  const id = products.length ? products[products.length-1].id + 1 : 1;
  const p = { id, name, price };
  products.push(p);
  res.status(201).json(p);
});

app.get('/api/health', (req,res)=>res.json({status:'ok'}));

const PORT = process.env.PORT || 5001;
app.listen(PORT, ()=>console.log('SmartCart backend running on', PORT));

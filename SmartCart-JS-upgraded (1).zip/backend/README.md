Node.js backend. Run `npm install` and `npm start`.
